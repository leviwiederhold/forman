"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { getErrorMessage } from "@/lib/http";

export default function ShareRespondButtons({
  token,
  disabled,
}: {
  token: string;
  disabled?: boolean;
}) {
  const [busy, setBusy] = React.useState<"accept" | "reject" | null>(null);
  const [msg, setMsg] = React.useState<string | null>(null);

  async function setStatus(next: "accepted" | "rejected") {
    try {
      setBusy(next === "accepted" ? "accept" : "reject");
      setMsg(null);

      const res = await fetch(`/api/quotes/share/${token}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: next }),
      });

      const json: unknown = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(getErrorMessage(json, "Failed to update status"));

      setMsg("Updated!");
      window.location.reload();
    } catch (e: unknown) {
      setMsg(e instanceof Error ? e.message : "Failed");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <Button
        variant="secondary"
        disabled={Boolean(disabled) || busy !== null}
        onClick={() => setStatus("accepted")}
      >
        {busy === "accept" ? "Accepting…" : "Accept Quote"}
      </Button>

      <Button
        variant="outline"
        disabled={Boolean(disabled) || busy !== null}
        onClick={() => setStatus("rejected")}
      >
        {busy === "reject" ? "Rejecting…" : "Reject Quote"}
      </Button>

      {msg ? <span className="text-xs text-foreground/60">{msg}</span> : null}
    </div>
  );
}
