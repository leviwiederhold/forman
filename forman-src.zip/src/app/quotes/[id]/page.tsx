import { redirect } from "next/navigation";

import { createSupabaseServerClient } from "@/lib/supabase/server";
import type { JsonObject, JsonValue } from "@/lib/types/json";

type PageProps = {
  params: Promise<{ id: string }> | { id: string };
};

type QuoteView = {
  id: string;
  trade: string;
  customer_name: string | null;
  customer_address: string | null;
  inputs_json: JsonObject | null;
  selections_json: JsonObject | null;
  line_items_json: JsonValue | null;
  subtotal: number | null;
  tax: number | null;
  total: number | null;
  status: string | null;
  created_at?: string | null;
};

export default async function QuoteDetailPage({ params }: PageProps) {
  const { id } = await Promise.resolve(params);

  const supabase = await createSupabaseServerClient();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) redirect("/login");

  const { data: quote, error } = await supabase
    .from("quotes")
    .select(
      "id, trade, customer_name, customer_address, inputs_json, selections_json, line_items_json, subtotal, tax, total, status, created_at"
    )
    .eq("id", id)
    .single<QuoteView>();

  if (error || !quote) redirect("/quotes");

  return (
    <div className="space-y-3 p-6">
      <div className="text-lg font-medium">Quote</div>
      <div className="text-sm text-muted-foreground">
        {quote.customer_name ?? "Unnamed"} — {quote.status ?? "draft"}
      </div>
      <div className="text-sm">
        Total:{" "}
        <span className="font-medium">${(quote.total ?? 0).toFixed(2)}</span>
      </div>
    </div>
  );
}
