import { redirect } from "next/navigation";

import { createSupabaseServerClient } from "@/lib/supabase/server";
import type { JsonObject, JsonValue } from "@/lib/types/json";

type PageProps = {
  params: { id: string };
};

type QuoteView = {
  id: string;
  trade: string;
  customer_name: string | null;
  customer_address: string | null;
  inputs_json: JsonObject | null;
  selections_json: JsonObject | null;
  line_items_json: JsonValue | null;
  subtotal: number | null;
  tax: number | null;
  total: number | null;
  status: string | null;
};

export default async function QuoteEditPage({ params }: PageProps) {
  const supabase = await createSupabaseServerClient();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) redirect("/login");

  const { data: quote, error } = await supabase
    .from("quotes")
    .select(
      "id, trade, customer_name, customer_address, inputs_json, selections_json, line_items_json, subtotal, tax, total, status"
    )
    .eq("id", params.id)
    .single<QuoteView>();

  if (error || !quote) {
    redirect("/quotes");
  }

  // Your existing "edit via /quotes/new?edit=<id>" flow
  redirect(`/quotes/new?edit=${quote.id}`);
}
