import { NextResponse } from "next/server";
import { z } from "zod";
import { createSupabaseServerClient } from "@/lib/supabase/server";

const BodySchema = z.object({
  email: z.string().email(),
});

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  const supabase = await createSupabaseServerClient();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const parsed = BodySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid email" }, { status: 400 });
  }

  // Confirm quote exists + belongs to user (RLS also protects)
  const { data: quote } = await supabase
    .from("quotes")
    .select("id")
    .eq("id", id)
    .single();

  if (!quote) return NextResponse.json({ error: "Quote not found" }, { status: 404 });

  // Stub: later you'll integrate Resend / Postmark / SendGrid
  // For now, return success so UI flow works.
  return NextResponse.json(
    { ok: true, message: "Email sending not implemented yet.", to: parsed.data.email },
    { status: 200 }
  );
}
