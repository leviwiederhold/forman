import { NextResponse } from "next/server";

import { createSupabaseServerClient } from "@/lib/supabase/server";

type Params = { id: string };

function randomToken(len = 22): string {
  const chars =
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_";
  let out = "";
  for (let i = 0; i < len; i += 1) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

// POST /api/quotes/:id/share
// Ensures a share_token exists and returns it.
// (Quote viewing by token is done via /quotes/share/[token] with public RLS + x-share-token header.)
export async function POST(
  _req: Request,
  { params }: { params: Promise<Params> }
) {
  const { id } = await params;

  const supabase = await createSupabaseServerClient();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { data: existing, error: fetchErr } = await supabase
    .from("quotes")
    .select("id, share_token")
    .eq("id", id)
    .single<{ id: string; share_token: string | null }>();

  if (fetchErr || !existing) {
    return NextResponse.json({ error: "Quote not found" }, { status: 404 });
  }

  const token = existing.share_token ?? randomToken();

  if (!existing.share_token) {
    const { error: updateErr } = await supabase
      .from("quotes")
      .update({ share_token: token })
      .eq("id", id);

    if (updateErr) {
      return NextResponse.json({ error: updateErr.message }, { status: 500 });
    }
  }

  return NextResponse.json({
    share_token: token,
    share_url: `/quotes/share/${token}`,
  });
}
