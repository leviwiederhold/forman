"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { getErrorMessage, getStringField } from "@/lib/http";

export function ShareLinkButton({ quoteId }: { quoteId: string }) {
  const [loading, setLoading] = React.useState(false);
  const [msg, setMsg] = React.useState<string | null>(null);

  async function copy() {
    try {
      setLoading(true);
      setMsg(null);

      const res = await fetch(`/api/quotes/${quoteId}/share`, { method: "POST" });
      const json: unknown = await res.json().catch(() => ({}));

      if (!res.ok) throw new Error(getErrorMessage(json, "Failed to generate share link"));

      const shareUrl = getStringField(json, "share_url");
      if (!shareUrl || !shareUrl.includes("/quotes/share/")) {
        throw new Error("Bad share URL returned");
      }

      await navigator.clipboard.writeText(shareUrl);
      setMsg("Copied!");
      setTimeout(() => setMsg(null), 1200);
    } catch (e: unknown) {
      setMsg(e instanceof Error ? e.message : "Copy failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex items-center gap-2">
      <Button variant="outline" onClick={copy} disabled={loading}>
        {loading ? "Generating…" : "Copy Link"}
      </Button>
      {msg ? <span className="text-xs text-foreground/60">{msg}</span> : null}
    </div>
  );
}
