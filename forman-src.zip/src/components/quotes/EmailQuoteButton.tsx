"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { getErrorMessage, getStringField } from "@/lib/http";

export function EmailQuoteButton({
  quoteId,
  customerName,
  total,
}: {
  quoteId: string;
  customerName?: string | null;
  total?: number | null;
}) {
  const [loading, setLoading] = React.useState(false);

  async function email() {
    try {
      setLoading(true);

      const res = await fetch(`/api/quotes/${quoteId}/share`, { method: "POST" });
      const json: unknown = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(getErrorMessage(json, "Failed to generate share link"));

      const shareUrl = getStringField(json, "share_url");

      const subject = `Roofing Quote${customerName ? ` - ${customerName}` : ""}`;
      const bodyLines = [
        `Hi${customerName ? ` ${customerName}` : ""},`,
        ``,
        `Here is your roofing quote${total != null ? ` for $${Number(total).toFixed(2)}` : ""}:`,
        shareUrl,
        ``,
        `Thanks,`,
        `Forman`,
      ];

      window.location.href = `mailto:?subject=${encodeURIComponent(
        subject
      )}&body=${encodeURIComponent(bodyLines.join("\n"))}`;
    } finally {
      setLoading(false);
    }
  }

  return (
    <Button variant="outline" onClick={email} disabled={loading}>
      {loading ? "Preparing…" : "Email"}
    </Button>
  );
}
